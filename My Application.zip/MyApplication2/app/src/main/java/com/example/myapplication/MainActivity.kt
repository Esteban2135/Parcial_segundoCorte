package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        buttonSend.button {
            val name = editTextText.text.toString()
            val intent = Intent(this, MainActivity2::class.java)
            intent.putExtra("Juan Garzon", name)
            startActivity(intent)
        }
    }
}





















val editTextText = null
val buttonSend = null
private val Nothing?.text: Any
    get() {
        TODO("Not yet implemented")
    }
private fun Nothing?.button(function: () -> Unit) {
    TODO("Not yet implemented")
}
